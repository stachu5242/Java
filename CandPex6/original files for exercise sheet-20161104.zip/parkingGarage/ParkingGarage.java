package parkingGarage;

public class ParkingGarage {
	private int freePlaces;
	
	public ParkingGarage(int freePlaces) {
		this.freePlaces = freePlaces;
	}
	
	public synchronized void enter() {
		while (freePlaces == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		freePlaces--;
		notifyAll();
	}
	
	public synchronized void leave() {
		freePlaces++;
		notifyAll();
	}
}
