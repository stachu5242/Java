package parkingGarage;

class Car extends Thread
{
	private ParkingGarage garage;

	public Car(ParkingGarage garage)
	{
    	this.garage = garage;
    }

	public void run()
	{
    	try {
			sleep((int) (Math.random() * 150));
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
    	garage.enter();
    	System.out.println(getName() + " entering the garage.");
    	try {
			sleep((int) (Math.random() * 300));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	System.out.println(getName() + " leaving the garage.");
    	garage.leave();
    }
}
